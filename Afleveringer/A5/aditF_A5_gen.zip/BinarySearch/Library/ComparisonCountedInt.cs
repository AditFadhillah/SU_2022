using System;

namespace Library {
    public class ComparisonCountedInt : IComparable{
        public int countValue {get;}
        
        public int counter {get; private set;}

        public ComparisonCountedInt (int value) {
            countValue = value;
            counter = 0;
        }
        
        public int CompareTo(object obj) {
            counter++;
            if(obj == null) {
                return -1;
            }
            else if (obj is ComparisonCountedInt objInt) {
                return countValue.CompareTo(objInt.countValue);
            } 
            else {
                throw new ArgumentException("Object is not a ComparisonCountedInt");
            }
        }

        public static int CountComparisons(ComparisonCountedInt[] array) {
            int sum = 0;
            foreach(var i in array) {
                sum += i.counter;
            }
            return sum;
        }
        
    }
}