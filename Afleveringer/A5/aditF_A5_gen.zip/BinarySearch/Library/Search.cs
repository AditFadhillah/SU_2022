using System;

namespace Library {
    public static class Search {

        /// <summary>
        /// A searhing algorithm that searches binary through an IComparable array
        /// </summary>
        /// <param name="array"> IComparable array </param>
        /// <param name="target"> IComparable element </param>
        /// <returns> Returns -1 or an integer corresponding to an index </returns>
        public static int Binary(IComparable[] array, IComparable target) {
            var low = 0;
            var high = array.Length - 1;
            if (array == null || array.Length == 0) {
                return -1;
            }
            else if (target.CompareTo(array[0]) == 0) {
                return 0;
            }
            else if (target.CompareTo(array[0]) < 0 || target.CompareTo(array[array.Length-1]) > 0) {
                return -1;
            }
            else {
                while (low <= high) {
                    var mid = low + ((high - low) / 2);
                    var midVal = array[mid];
                    var relation = midVal.CompareTo(target);

                    if (relation < 0) {
                        low = mid + 1;
                    } else if (relation > 0) {
                        high = mid - 1;
                    } else {
                        while (mid != 0 && array[mid-1].CompareTo(target) == 0) {
                            mid =- 1;
                        }
                        return mid;
                    }
                }
            }
            return -1;
        }


        /// <summary>
        /// A searching algorithm that uses searches linearly through an IComparable array.
        /// </summary>
        /// <param name="array"> IComparable array </param>
        /// <param name="target"> IComparable element </param>
        /// <returns> Returns -1 or an integer corresponding to an index </returns>
        public static int Linear(IComparable[] array, IComparable target) {
            foreach(IComparable elem in array) {
                if(target.CompareTo(elem) == 0) {
                    return Array.IndexOf(array,elem);
                }
            }
            return -1;
        }
    }
}