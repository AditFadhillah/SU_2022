﻿using Library;
using NUnit.Framework;
using PersonNS;
using System;

namespace Tests {
    [TestFixture]
    public class Test {
        [SetUp]
        public void Init() {
            gen = new Generator();
        }

        private Generator gen;


        [Test]
        // Test to see that the algorithm will return -1, if the target is not within the array
        public void TestTooLow() {
            var array = gen.NextArray(5,5);
            Assert.AreEqual(Search.Binary(array, -1), -1);
        }
        

        [Test]
        // Test to see that the algorithm will return -1, if the target is not within the array
        public void TestTooHigh() {
            var array = gen.NextArray(5,5);
            Assert.AreEqual(Search.Binary(array, 6), -1);
        }


        [Test]
        // Test to see that a target is within the array
        public void TestElement() {
            IComparable[] array = new IComparable[] {2,4,6,8,10};
            // 4 is in the array, and therefore not equal to -1
            Assert.AreNotEqual(Search.Binary(array, 4), -1);
        }


        [Test]
        // Tests an empty array
        public void TestEmptyArray() {
            IComparable[] array = new IComparable[] {};
            int i = 0;
            for(i = -100; i<=100; i++) {
                Assert.AreEqual(Search.Binary(array, i), -1);
            }
        }


        [Test]
        // Test to see that index proritize the left most position
        public void TestSameValue() {
            IComparable[] array = new IComparable[] {1,0,1,1,1,1};
            Assert.AreEqual(Search.Binary(array, 1), 0);
        }


        [Test]
        // Test to see that index proritize the left most position
        public void TestSameValue2() {
            IComparable[] array = new IComparable[] {0,0,0,1,0,1};
            Assert.AreEqual(Search.Binary(array, 0), 0);
        }


        [Test]
        // Test for a single element array
        public void TestSingleValue() {
            IComparable[] array = new IComparable[] {1};
            Assert.AreEqual(Search.Binary(array, 1), 0);
        }


        [Test]
        // Tests to make sure that binary search works with the Person data type. 
        public void TestPerson() {
            Person Kristoffer = new Person("Kristoffer", 26);
            Person Usama = new Person("Usama", 24);
            Person Adit = new Person("Adit", 21);
            Person Sia = new Person("Sia", 20);
            IComparable[] personArray = new IComparable[] {Kristoffer, Usama, Adit, Sia};
            Assert.AreEqual(2, Search.Binary(personArray, Adit));
        }


        [Test]
        public void TestPersonNotFound() {
            Person Kristoffer = new Person("Kristoffer", 26);
            Person Usama = new Person("Usama", 24);
            Person Kevin = new Person("Kevin", 23);
            Person Adit = new Person("Adit", 21);
            Person Sia = new Person("Sia", 20);
            IComparable[] personArray = new IComparable[] {Kristoffer, Usama, Adit, Sia};
            Assert.AreEqual(-1, Search.Binary(personArray, Kevin));
        }


        [TestCase(1)]
        [TestCase(50)]
        [TestCase(100)]
        [TestCase(1000)]
        // Tests to ensure that binary search does not overstep logarithmic bound. 
        public void TestRunningTime(int size) {
            ComparisonCountedInt[] array = gen.NextArrayComparison(size, 2000);
            int prevComp = ComparisonCountedInt.CountComparisons(array);
            Search.Binary(array, new ComparisonCountedInt(100));
            // Subtracting the previous comparison to accurately calculate the new comparison.
            int test = ComparisonCountedInt.CountComparisons(array) - prevComp;
            int math = (int)Math.Ceiling(Math.Log(size, 2.0));
            // checks if CountComparison return a value that is within logarithmic bound.
            Assert.LessOrEqual(test, math);
        }


        [Test]
        // Test to see Linear returns the correct index.
        public void TestLinear() {
            IComparable[] array = new IComparable[] {2,4,6,8,10};
            Assert.AreEqual(Search.Binary(array, 6), 2);
        }


        [TestCase(2)]
        [TestCase(6)]
        [TestCase(10)]
        [TestCase(0)]
        // Test that linear search and binary search returns the same index 
        public void TestSameIndex(int target) {
            IComparable[] array = new IComparable[] {2,4,6,8,10};
            Assert.AreEqual(Search.Binary(array, target), Search.Linear(array, target));
        }


        [TestCase(1)]
        [TestCase(10)]
        [TestCase(100)]
        [TestCase(1000)]
        // Test that binary search performs fewer comparisons than Linear search.
        public void TestLinearVBinary(int size) {
            ComparisonCountedInt[] array = gen.NextArrayComparison(size, 2000);
            ComparisonCountedInt[] array2 = array;
            int prevComp = ComparisonCountedInt.CountComparisons(array);
            int prevComp2 = ComparisonCountedInt.CountComparisons(array2);
            // Subtracting the previous comparison to accurately calculate the new comparison.
            int binary = Search.Binary(array, new ComparisonCountedInt(500))- prevComp;
            int linear = Search.Linear(array2, new ComparisonCountedInt(500)) - prevComp2;
            Assert.LessOrEqual(binary, linear);
        }
    }
}
