using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using System.IO;
using System.Collections.Generic;
namespace Galaga {
    public class Enemy : Entity {
        private int hitpoints;
        public Enemy(DynamicShape shape, IBaseImage image) : base(shape, image) {
            hitpoints = 3; 
        }

        public int Hitpoints {
            get{return hitpoints;} 
            set{Hitpoints = value;}
        }

        /// <summary>
        /// Reduces the enemy's hitpoints by 1
        /// </summary>
        public void ReduceHP () {
            hitpoints -= 1;
        }
    }
}