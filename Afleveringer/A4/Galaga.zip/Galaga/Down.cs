using Galaga.MovementStrategy;
using DIKUArcade.Entities;
namespace Galaga {
    public class Down : IMovementStrategy {
        private float s;
        public Down() {
            s = 0.0003f;
        }
        public float Speed {
            get {return s;}
            set {s = value;}
        }

        /// <summary>
        /// Moves enemy down.
        /// </summary>
        public void MoveEnemy (Enemy enemy) {
            enemy.Shape.MoveY(-s);
        }

        /// <summary>
        /// Calls every enemies in EntityContainer<Enemy> to move.
        /// </summary>
        public void MoveEnemies (EntityContainer<Enemy> enemies) {
            foreach(Enemy enemy in enemies) {
                MoveEnemy(enemy);
            }
        }

        /// <summary>
        /// Increase speed with a variable.
        /// </summary>
        public void IncreaseSpeed (float inc) {
            Speed =+ inc;
        }
    }
}