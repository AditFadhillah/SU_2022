using DIKUArcade.Entities;
using System.IO;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using System.Collections.Generic;
using Galaga.Squadron;

namespace Galaga {
    public class FormationA : ISquadron{

        public EntityContainer<Enemy> Enemies {get;}
        public FormationA () {
            Enemies = new EntityContainer<Enemy>(MaxEnemies);
            MaxEnemies = 8;
        }
        public int MaxEnemies {get;}
        
        /// <summary>
        /// Spawns enemies in a formation.
        /// </summary>
        public void CreateEnemies(List<Image> enemyStride, List<Image> alternativeEnemyStride) {
            for (int i = 0; i < MaxEnemies; i++) {
                Enemies.AddEntity(new Enemy(
                    new DynamicShape(new Vec2F(0.1f + (float)i * 0.1f, 0.93f), new Vec2F(0.1f, 0.1f)),
                    new ImageStride(80, enemyStride)));
            }
        }
    }
}