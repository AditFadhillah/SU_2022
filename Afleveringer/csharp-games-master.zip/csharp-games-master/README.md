# Several games (C#)
Results of the course "Game Programming Patterns" at the HS Bremen from Niklas Hinte and Jannis Jahr

## List of Games
* Breakout Game
* Jump'n'Run Game
* Pong Game
* SpaceShooter Game

## Installation
Install Visual-Studio 2013/2015. Get the NuGet Package manager and install the packages. Select the Game you want to build. Click on Build - the game will be built and started.
