using DIKUArcade.Events;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
namespace Galaga {
    public class Player : IGameEventProcessor{
        private Entity entity;
        private DynamicShape shape;
        public Player(DynamicShape shape, IBaseImage image) {
            entity = new Entity(shape, image);
            this.shape = shape;
        }
        public Entity Entity {
            get {return entity;}
            set {entity = value;}
        }

        /// <summary>
        /// Renders entity.
        /// </summary>
        public void Render() {
            entity.RenderEntity();
        }
        private float moveLeft = 0.0f;
        private float moveRight = 0.0f;
        private const float MOVEMENT_SPEED = 0.02f;

        /// <summary>
        /// Sets a border and moves the Player.
        /// </summary>
        public void Move() {
            if (shape.Position.X <= (0.0f)) {
                shape.Position.X = 0.0f;
            }
            else if (shape.Position.X >= (0.9f)) {
                shape.Position.X = 0.9f;
            }
            shape.Move();
        }

        /// <summary>
        /// Sets the moving direction to the left.
        /// </summary>
        private void SetMoveLeft(bool val) {
            if (val) {
                moveLeft -= MOVEMENT_SPEED;
            }  
            else {
                moveLeft = 0.0f;
            }
            UpdateDirection();
        }

        /// <summary>
        /// Sets the moving direction to the right.
        /// </summary>
        private void SetMoveRight(bool val) {
            if (val) {
                moveRight += MOVEMENT_SPEED;
            }  
            else {
                moveRight = 0.0f;
            }
            UpdateDirection();
        }

        /// <summary>
        /// Sets the moving direction to neutral.
        /// </summary>
        private void UpdateDirection(){
            shape.Direction.X = moveLeft+moveRight;
        }   

        /// <summary>
        /// returns the position of the Player.
        /// </summary>
        public Vec2F GetPosition(){
            return (shape.Position);
        }

        /// <summary>
        /// Processes the different gameEvents, by using gameEvent.Message.
        /// </summary>
        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.EventType == GameEventType.InputEvent) {
                switch (gameEvent.Message) {
                    case "LeftGo":
                        SetMoveLeft(true);
                        break;
                    case "RightGo":
                        SetMoveRight(true);
                        break;
                    case "LeftStop":
                        SetMoveLeft(false);
                        break;
                    case "RightStop":
                        SetMoveRight(false);
                        break;  
                    default:
                        break;  
                }
            }
        }
    }
}