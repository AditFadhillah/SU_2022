using DIKUArcade.Entities;
using System.IO;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using System.Collections.Generic;
using Galaga.Squadron;

namespace Galaga {
    public class FormationB : ISquadron{

        public EntityContainer<Enemy> Enemies {get;}
        public FormationB () {
            Enemies = new EntityContainer<Enemy>(MaxEnemies);
            MaxEnemies = 8;
        }
        public int MaxEnemies {get;}
        
        /// <summary>
        /// Spawns enemies in a formation.
        /// </summary>
        public void CreateEnemies(List<Image> enemyStride, List<Image> alternativeEnemyStride) {
            for (int i = 0; i < MaxEnemies/2; i++) {
                Enemies.AddEntity(new Enemy(
                    new DynamicShape(new Vec2F(0.1f + (float)i * 0.1f, 0.8f + (float)i*0.05f), new Vec2F(0.1f, 0.1f)),
                    new ImageStride(80, enemyStride)));
            }
            for (int i = MaxEnemies/2; i < MaxEnemies; i++) {
                Enemies.AddEntity(new Enemy(
                    new DynamicShape(new Vec2F(0.1f + (float)i * 0.1f, 1.15f + (float)i*-0.05f), new Vec2F(0.1f, 0.1f)),
                    new ImageStride(80, enemyStride)));
            }
        }
    }
}