using DIKUArcade.Math;
using DIKUArcade.Graphics;
namespace Galaga {
    public class Score {
        private int score;
        private Text display;
        public Score (Vec2F position, Vec2F extent) {
            score = 0;
            display = new Text (score.ToString(), position, extent);
            display.SetColor(255, 255, 0, 0);
        }

        /// <summary>
        /// Increase score by 1.
        /// </summary>
        public void AddPoints () {
            score += 1;
        }

        /// <summary>
        /// Render and update score.
        /// </summary>
        public void RenderScore () {
            display.SetText("Score: " + score.ToString());
            display.RenderText();
        }
    }

}