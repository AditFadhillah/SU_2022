using Galaga.MovementStrategy;
using DIKUArcade.Entities;
using DIKUArcade.Math;
using System;
namespace Galaga {
    public class ZigZag : IMovementStrategy {
        private float s;
        public ZigZag() {
            s = 0.0003f;
        }
        public float Speed {
            get {return s;}
            set {s = value;}
        }

        /// <summary>
        /// Moves enemy down in a zigzag pattern.
        /// </summary>
        public void MoveEnemy (Enemy enemy) {
            float p = 0.045f;
            float a = 0.005f;
            Vec2F startPos = enemy.Shape.Position;
            float x0 = startPos.X;
            float y0 = startPos.Y;
            enemy.Shape.MoveY(-s);
            float yi = startPos.Y - enemy.Shape.Position.Y + s;
            enemy.Shape.Position.X = x0 + a * (float)Math.Sin((2.0f * Math.PI*(y0-yi))/p);
        }

        /// <summary>
        /// Calls every enemies in EntityContainer<Enemy> to move.
        /// </summary>
        public void MoveEnemies (EntityContainer<Enemy> enemies) {
            foreach(Enemy enemy in enemies) {
                MoveEnemy(enemy);
            }
        }

        /// <summary>
        /// Increase speed with a variable.
        /// </summary>
        public void IncreaseSpeed (float inc) {
            Speed =+ inc;
        }
    }
}