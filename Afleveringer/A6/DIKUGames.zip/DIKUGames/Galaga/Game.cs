using DIKUArcade;
using DIKUArcade.GUI;
using DIKUArcade.Input;
using System.IO;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
using System.Security.Principal;
using System.Collections.Generic;
using DIKUArcade.Events;
using DIKUArcade.Physics;
using Galaga.Squadron;
using Galaga.MovementStrategy;
using System;
namespace Galaga
{
    public class Game : DIKUGame, IGameEventProcessor{
        private EntityContainer<PlayerShot> playerShots;
        private IBaseImage playerShotImage;
        // private EntityContainer<Enemy> enemies;
        private GameEventBus eventBus;
        private Player player;
        private AnimationContainer enemyExplosions;
        private List<Image> explosionStrides;
        private List<Image> enemyStridesGreen;
        private List<Image> enemyStridesBlue;
        private const int EXPLOSION_LENGTH_MS = 500;
        private ISquadron enemyFormation;
        private IMovementStrategy enemyMovement;
        private Score points;
        private float inc;
        private bool isOver;

        // Constructor
        public Game(WindowArgs windowArgs) : base(windowArgs) {
            // Player
            player = new Player(
                new DynamicShape(new Vec2F(0.45f, 0.009f), new Vec2F(0.1f, 0.1f)),
                new Image(Path.Combine("Assets", "Images", "Player.png")));
            
            // EventBus
            eventBus = new GameEventBus();
            eventBus.InitializeEventBus(new List<GameEventType> { GameEventType.InputEvent });
            
            // Subscribers
            window.SetKeyEventHandler(KeyHandler);
            eventBus.Subscribe(GameEventType.InputEvent, this);
            eventBus.Subscribe(GameEventType.InputEvent, player);

            // Green monster
            enemyStridesGreen = ImageStride.CreateStrides(2, 
                Path.Combine("Assets","Images", "GreenMonster.png"));

            // Blue monster
            enemyStridesBlue = ImageStride.CreateStrides(4, 
                Path.Combine("Assets","Images", "BlueMonster.png"));

            // Enemy formation
            enemyFormation = new FormationA();
            enemyFormation.CreateEnemies(enemyStridesBlue, enemyStridesGreen);

            // Shots
            playerShots = new EntityContainer<PlayerShot>();
            playerShotImage = new Image(Path.Combine("Assets", "Images", "BulletRed2.png"));

            // Explosion
            enemyExplosions = new AnimationContainer(enemyFormation.MaxEnemies);
            explosionStrides = ImageStride.CreateStrides(8,
                Path.Combine("Assets", "Images", "Explosion.png"));
            
            // Enemy Movement
            enemyMovement = new Down();
            inc = 0.0003f;

            // Score
            points = new Score(new Vec2F(0.07f, -0.2f), new Vec2F(0.3f, 0.3f));
            isOver = false;
        }
        // render the different elements in the game
        public override void Render() {
            if(isOver == false) {
                player.Render();
            }
            enemyFormation.Enemies.RenderEntities();
            playerShots.RenderEntities();
            enemyExplosions.RenderAnimations();
            points.RenderScore();
        }
        // updates the actions of the different elements in the game
        public override void Update() {   
            eventBus.ProcessEventsSequentially();
            player.Move();
            IterateShots();
            NextFormation();
            enemyMovement.MoveEnemies(enemyFormation.Enemies);
            GameOver();
        }

        /// <summary>
        /// Calls to KeyPress() if KeyboardAction is KeyPress.
        /// Calls to KeyRelease() if KeyboardAction is KeyRelease.
        /// </summary>
        private void KeyHandler(KeyboardAction action, KeyboardKey key) {
            // handles the different key actions and specific keys
            switch (action) {
                case KeyboardAction.KeyPress:
                    KeyPress(key);
                    break;
                case KeyboardAction.KeyRelease:
                    KeyRelease(key);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Register a new gameEvent by using variable key.
        /// Key comes from KeyHandler
        /// Uses the gameEvent.Message to name different gameEvent.
        /// </summary>
        public void KeyPress(KeyboardKey key) {
                // makes a gameevent when a key is pressed, that gameevent contains a message corresponding to its purpose
                switch (key){
                case KeyboardKey.Left:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "LeftGo" });
                    break;
                case KeyboardKey.Right:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "RightGo" });
                    break;
                case KeyboardKey.Escape:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "Escape" });
                    break;
                case KeyboardKey.Space:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "Shoot" });
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Register a new gameEvent by using variable key.
        /// Key comes from KeyHandler
        /// Uses the gameEvent.Message to name different gameEvent.
        /// </summary>
        public void KeyRelease(KeyboardKey key) {
            // makes a gameevent when a key is pressed, that gameevent contains 
            // a message corresponding to its purpose
            switch (key){
                // makes a gameevent with a message "LeftStop"
                case KeyboardKey.Left:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "LeftStop" });
                    break;
                // makes a gameevent with a message "RightStop"
                case KeyboardKey.Right:
                    eventBus.RegisterEvent (new GameEvent {
                        EventType = GameEventType.InputEvent, From = this,
                        Message = "RightStop" });
                    break;
                default:
                    break;
            }
        }
        /// <summary>
        /// Processes the different gameEvents, by using gameEvent.Message.
        /// </summary>
        public void ProcessEvent(GameEvent gameEvent) {
            if (gameEvent.EventType == GameEventType.InputEvent) {
                switch (gameEvent.Message) {
                    case "Escape":
                        window.CloseWindow();
                        break;  
                    // spawns a shot in the player's position
                    case "Shoot":
                        PlayerShot sht = new PlayerShot(
                            new DynamicShape(
                                player.GetPosition() + new Vec2F(0.05f,0.0f), 
                                new Vec2F(0.008f, 0.021f), new Vec2F(0.0f, 0.1f)),
                                playerShotImage);
                        playerShots.AddEntity(sht);
                        break; 
                    default:
                        break;  
                }
            }
        }
        /// <summary>
        /// Makes shots, determined the shots attributes.
        /// Deletes the shots when it comes in contact with the border or enemies.
        /// Changes the enemy's attributes when in contact with a shot.
        /// </summary>
        private void IterateShots() {
            // spawns a shot
            playerShots.Iterate(shot => {
                // moves the shot
                shot.Shape.Move();
                // deletes a shot when it hits the top of the window
                if (shot.Shape.Position.Y > 1) {
                    shot.DeleteEntity();
                } 
                else {
                    enemyFormation.Enemies.Iterate(enemy => {
                        // deletes shots and enemy when they collide, and makes an explosion
                        if (CollisionDetection.Aabb(shot.Shape.AsDynamicShape(), enemy.Shape).Collision == true) {
                            enemy.ReduceHP();
                            if (enemy.Hitpoints <= 2) {
                                // enemy turns green and have a faster animation
                                enemy.Image = new ImageStride(40, enemyStridesGreen);
                            }
                            if (enemy.Hitpoints <= 0) {
                                enemy.DeleteEntity();
                                AddExplosion(enemy.Shape.Position, enemy.Shape.Extent);
                                points.AddPoints();
                            }
                            shot.DeleteEntity();
                        }
                    });
                }
            });
        }

        /// <summary>
        /// Makes an explosion animation
        /// </summary>
        public void AddExplosion(Vec2F position, Vec2F extent) {
            // set where explosion sprite spawns
            StationaryShape stationaryShape = new StationaryShape(position, extent);
            ImageStride images = new ImageStride(5, explosionStrides);
            // set how long the animation is
            enemyExplosions.AddAnimation(stationaryShape, EXPLOSION_LENGTH_MS, images);
        }

        /// <summary>
        /// Spawns a new set of enemy with increase speed and 3 presets of formation and movement.
        /// Uses a random number generator to pick a number between 0 to 2.
        /// </summary>
        public void NextFormation() {
            if(isOver == false) {
                Random rnd = new Random();
                int num = rnd.Next(0,3);
                if(enemyFormation.Enemies.CountEntities() <= 0) {
                    switch (num) {
                        case (0):
                            enemyFormation = new FormationA();
                            enemyFormation.CreateEnemies(enemyStridesBlue, enemyStridesGreen);
                            enemyMovement = new Down();
                            enemyMovement.IncreaseSpeed(inc);
                            inc =+ inc+inc;
                        break;
                        case (1):
                            enemyFormation = new FormationB();
                            enemyFormation.CreateEnemies(enemyStridesBlue, enemyStridesGreen);
                            enemyMovement = new ZigZag();
                            enemyMovement.IncreaseSpeed(inc);
                            inc =+ inc+inc;
                        break;
                        case (2):
                            enemyFormation = new FormationC();
                            enemyFormation.CreateEnemies(enemyStridesBlue, enemyStridesGreen);
                            enemyMovement = new ZigZag();
                            enemyMovement.IncreaseSpeed(inc);
                            inc =+ inc+inc;
                        break;
                        default:
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Checks if any enemy has reached the bottow.
        /// Deletes all enemies and player if isOver is true.
        /// </summary>
        private void GameOver() {
            foreach (Enemy enemy in enemyFormation.Enemies) {
                if(enemy.Shape.Position.Y <= 0.01f){
                    isOver = true;
                }
            }
            if(isOver == true) {
                enemyFormation.Enemies.ClearContainer();
            }
        }
    }
}
