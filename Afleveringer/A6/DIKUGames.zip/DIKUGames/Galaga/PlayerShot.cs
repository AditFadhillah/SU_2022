using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;
namespace Galaga;

    public class PlayerShot : Entity {
        private Entity entity;
        private static Vec2F shotExt;
        private static Vec2F shotDir;
        public PlayerShot (DynamicShape shape, IBaseImage image) : base(shape,image) {
            entity = new Entity(shape, image);
            shotExt = new Vec2F(0.008f, 0.021f);
            shotDir = new Vec2F(0.0f, 0.1f); 
        }   
        public Vec2F ShotExt {
            get{
                return shotExt;
            }
            set{
                shotExt = value;
            }
        }
        public Vec2F ShotDir {
            get{
                return shotDir;
            }
            set{
                shotDir = value;
            }
        }
    }
