namespace DIKULecture
{
    public class Program
    {
        static void Main (string[] args)
        {
            Lecture SU = new Lecture ("SU");
            Lecture INTER = new Lecture ("INTER");
            Student Anders = new Student ("Anders", "student", 22);
            Student Boris = new Student ("Boris", "student", 24);
            Student Casper = new Student ("Casper", "student", 23);
            Speaker Dorthe = new Speaker ("Dorthe", "speaker", 44);
            
            Dorthe.Begin(SU);
            Dorthe.Begin(SU);
            Console.WriteLine(SU); 

            Anders.Join(SU);
            Boris.Join(SU);
            Casper.Join(SU);

            Dorthe.Broadcast("Cats sleep between 16 and 18 hours per day");
            Anders.Listen(SU);
            Console.WriteLine(SU); 

            Dorthe.changeName("INTER");
            Console.WriteLine(SU);

        }
    }
}

