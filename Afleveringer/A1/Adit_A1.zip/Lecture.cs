namespace DIKULecture
{
    public class Lecture : ChatRoom
    {
        public Lecture (string lectureName) : base (lectureName) 
        {
            numOfstudentsOnline = 0;
        }
        
        private int numOfstudentsOnline;
        private string information;
        public int NumOfstudentsOnline
        {
            get {return numOfstudentsOnline;}
            set {numOfstudentsOnline = value;}
        }
        public override String ToString()
        { 
            return String.Format("Lecture: " + this.Name + ". Number of students: " + NumOfstudentsOnline);
        }
        public string Information {get; set;}
    }
}
