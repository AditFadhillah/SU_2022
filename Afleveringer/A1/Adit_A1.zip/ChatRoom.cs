﻿namespace DIKULecture
{
    public class ChatRoom   //class
    {
        private string name;   //field        

        public ChatRoom(string roomName) //constructor
        {
            name = roomName;
        }
        public string Name
        {
            get {return name;}
            set {name = value;}
        }
        public void setName (string newName)
        {
            name = newName;
        }
    }

}

