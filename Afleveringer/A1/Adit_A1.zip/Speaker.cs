namespace DIKULecture
{
    public class Speaker : Person
    {
        private bool isInLecture;   
        private Lecture lecture;
        public Speaker (string sName, string sOccu, int sAge) : base (sName, sOccu, sAge) 
        {
            isInLecture = false;
            lecture = null;
        }
        public void Begin (Lecture newLecture)
        {
            if (isInLecture)
            {
                Console.WriteLine("The speaker ("+ this.Name + ") is starting the lecture ");
            }
            else
            {
                Console.WriteLine("The speaker ("+ this.Name + ") cannot begin the lecture as they are not in one");
                isInLecture = true;
                lecture = newLecture;
            }
        }
        public void Broadcast (string info)
        {
            if (isInLecture)
            {
                Console.WriteLine("The speaker ("+ this.Name + ") is broadcasting");
                lecture.Information = info;
            }
            else 
            {
                Console.WriteLine("The speaker ("+ this.Name + ") Cannot broadcast when not in a lecture");
            }
        }
        public void changeName (string newName)
        {
            Console.WriteLine("The speaker ("+ this.Name + ") changes the lecture name");
            lecture.setName(newName);
        }
    }
}   