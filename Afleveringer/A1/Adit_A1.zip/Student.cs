namespace DIKULecture
{
    public class Student : Person
    {
        private bool isInLecture = false;
        private Lecture lecture;
        public Student (string sName, string sOccu, int sAge) : base (sName, sOccu, sAge)
        {
            isInLecture = false;
            lecture = null;
        }
        public void Join (Lecture newLecture)
        {
            if (isInLecture)
            {
                Console.WriteLine("The student ("+ this.Name +") is already in a lecture");
            }
            else
            {
                Console.WriteLine("The student ("+ this.Name +") joined the lecture");
                isInLecture = true;
                newLecture.NumOfstudentsOnline++;
                lecture = newLecture;
            }
        }
        public void Listen (Lecture newLecture)
        {
            if (isInLecture)
            {
                Console.WriteLine("The student ("+ this.Name + ") has been given this information: ");
                Console.WriteLine(lecture.Information); 
            }
            else 
            {
                Console.WriteLine("The student ( "+ this.Name + ") is not in a lecture, and cannot listen to the information");
            }
        }
    }
}