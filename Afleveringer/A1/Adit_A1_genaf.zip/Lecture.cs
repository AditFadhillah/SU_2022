namespace DIKULecture
{
    public class Lecture : ChatRoom
    {   
        private int numOfstudentsOnline; //Field
        private string information;
        public Lecture (string lectureName) : base (lectureName) // Constructor
        {
            numOfstudentsOnline = 0;
            information = ""; 
        }
        public override String ToString() // Method
        { 
            return String.Format("Lecture: " + this.Name + ". Number of students: " + NumOfstudentsOnline);
        }
        public int NumOfstudentsOnline // Property
        {
            get {return numOfstudentsOnline;}
            set {numOfstudentsOnline = value;}
        }
        public string Information 
        {
            get {return information;}
            set {information = value;}
        }   
    }
}
