namespace DIKULecture
{
    public class Speaker : Person
    {
        private bool isInLecture;   //Field
        private Lecture lecture;
        public Speaker (string sName, string sOccu, int sAge) : base (sName, sOccu, sAge) //Constructor
        {
            isInLecture = false;
        }
        public void Begin (Lecture newLecture) //Method
        {
            if (isInLecture)
            {
                Console.WriteLine("The speaker ("+ this.Name + ") has already started a lecture");
            }
            else
            {
                Console.WriteLine("The speaker ("+ this.Name + ") is starting the lecture (" + newLecture.Name + ")");
                isInLecture = true;
                lecture = newLecture;
            }
        }
        public void Broadcast (string info)
        {
            if (isInLecture)
            {
                Console.WriteLine("The speaker ("+ this.Name + ") is broadcasting");
                lecture.Information = info;
            }
            else 
            {
                Console.WriteLine("The speaker ("+ this.Name + ") cannot broadcast when not in a lecture");
            }
        }
        public void Speak ()
        {
            if (isInLecture)
            {
                Console.WriteLine("The speaker ("+ this.Name + ") is speaking");
                Console.WriteLine("The speaker says: '" + lecture.Information + "'");
            }
            else 
            {
                Console.WriteLine("The speaker ("+ this.Name + ") cannot speak when not in a lecture");
            }
        }
        public void changeName (string newName)
        {
            Console.WriteLine("The speaker ("+ this.Name + ") changes the lecture name from (" + lecture.Name + ") to (" + newName + ")");
            lecture.setName(newName);
        }   
        public bool IsInLecture //Property
        {
            get {return isInLecture;}
            set {isInLecture = value;}
        }
    }
}   