namespace DIKULecture
{
    public class Student : Person
    {
        private bool isInLecture = false; //Field
        private Lecture lecture;
        public Student (string sName, string sOccu, int sAge) : base (sName, sOccu, sAge) //Constructor
        {
            isInLecture = false;
        }
        public void Join (Lecture newLecture) //Method
        {
            if (isInLecture)
            {
                Console.WriteLine("The student ("+ this.Name +") is already in a lecture (" + lecture.Name + "), and therefore cannot join (" + newLecture.Name + ")");
            }
            else
            {
                Console.WriteLine("The student ("+ this.Name +") joined the lecture (" + newLecture.Name + ")");
                isInLecture = true;
                newLecture.NumOfstudentsOnline++;
                lecture = newLecture;
            }
        }
        public void Listen (Lecture newLecture)
        {
            if (lecture == newLecture)
            {
                Console.WriteLine("The student ("+ this.Name + ") listened and has been given this information: [" + lecture.Information + "]");
            }
            else 
            {
                Console.WriteLine("The student ("+ this.Name + ") is not in (" + newLecture.Name + ") lecture, and cannot listen to the information");
            }
        }
        public bool IsInLecture //Property
        {
            get {return isInLecture;}
            set {isInLecture = value;}
        }
    }
}