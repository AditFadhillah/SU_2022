﻿namespace DIKULecture
{
    public class ChatRoom   //class
    {
        private string name;   //field        

        public ChatRoom(string roomName) //constructor
        {
            name = roomName;
        }
        public void setName (string newName) //method
        {
            name = newName;
        }
        public string Name //property
        {
            get {return name;}
            set {name = value;}
        }
    }

}

