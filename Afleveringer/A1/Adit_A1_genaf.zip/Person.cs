namespace DIKULecture
{
    public class Person 
    {
        private string name; //Field
        private string occupation;
        private int age;
        public Person(string sName, string sOccu, int sAge) //Constructor
        {
            name = sName;
            occupation = sOccu;
            age = sAge;
        }
        public override String ToString() // Method
        { 
            return String.Format("Name: " + this.Name + ". Occupation: " + this.Occupation+ ". Age: " + this.Age);
        }   
        public string Name //Property
        {
            get {return name;}
            set {name = value;}
        }
        public string Occupation
        {
            get {return occupation;}
            set {occupation = value;}
        }
        public int Age
        {
            get {return age;}
            set {age = value;}
        }
    }
}