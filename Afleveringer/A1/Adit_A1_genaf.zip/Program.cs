namespace DIKULecture
{
    public class Program
    {
        static void Main (string[] args)
        {
            Lecture SU = new Lecture ("SU");
            Lecture INTER = new Lecture ("INTER");
            Student Anders = new Student ("Anders", "student", 22);
            Student Boris = new Student ("Boris", "student", 24);
            Student Casper = new Student ("Casper", "student", 23);
            Speaker Dorthe = new Speaker ("Dorthe", "speaker", 44);
            Student Emil = new Student ("Emil", "student", 20);
            
            Dorthe.Broadcast("The world wastes about 1 billion metric tons of food each year.");
            Dorthe.Speak();
            Dorthe.Begin(SU);
            Dorthe.Begin(INTER);
            Console.WriteLine(SU + "\n"); 

            Emil.Join(INTER);
            Emil.Join(SU);
            Anders.Join(SU);
            Boris.Join(SU);
            Casper.Join(SU);
            Console.WriteLine(SU); 
            Console.WriteLine(INTER); 
            Console.Write("\n");

            Dorthe.Broadcast("The world wastes about 1 billion metric tons of food each year.");
            Dorthe.Speak();
            Anders.Listen(SU);
            Emil.Listen(SU);
            Console.Write("\n");

            Dorthe.changeName("CompSys");
            Console.WriteLine(SU);
            Console.Write("\n");
        }
    }
}

