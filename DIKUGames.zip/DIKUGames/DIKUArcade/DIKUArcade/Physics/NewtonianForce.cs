﻿using DIKUArcade.Math;

namespace DIKUArcade.Physics {
    public class NewtonianForce {
        //private Vec2F center;

        //private float falloff;

        // TODO: very barebones!
        //private float strengh;
    }
}