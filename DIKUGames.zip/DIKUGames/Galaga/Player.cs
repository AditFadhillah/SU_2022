using DIKUArcade.Entities;
using DIKUArcade.Graphics;
namespace Galaga {
    public class Player {
        private Entity entity;
        private DynamicShape shape;
        public Player(DynamicShape shape, IBaseImage image) {
            entity = new Entity(shape, image);
            this.shape = shape;
}
        public void Render() {
        // TODO: render the player entity
            entity.RenderEntity();
        }
        // TODO: Add private fields
        private float moveLeft = 0.0f;
        private float moveRight = 0.0f;
        private const float MOVEMENT_SPEED = 0.01f;
        public void Move() {
        // TODO: move the shape and guard against the window borders
        }
        public void SetMoveLeft(bool val) {
        // TODO:set moveLeft appropriately and call UpdateMovement()
            if (val) {
                moveLeft -= MOVEMENT_SPEED;
            } 
        }
        public void SetMoveRight(bool val) {
        // TODO:set moveRight appropriately and cal l UpdateMovement()
            if (val) {
                moveRight += MOVEMENT_SPEED;
            }
        private void UpdateDirection(){
            
        }
        }   
    }
}